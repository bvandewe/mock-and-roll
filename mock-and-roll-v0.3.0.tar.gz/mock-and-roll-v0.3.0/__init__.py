# This file makes the project a Python package for Poetry compatibility
__version__ = "0.1.0"
