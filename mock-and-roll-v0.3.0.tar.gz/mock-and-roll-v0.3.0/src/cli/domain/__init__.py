"""Domain layer for mock server CLI."""
