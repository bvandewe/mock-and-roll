"""Infrastructure layer for mock server CLI."""
