"""Interface layer for mock server CLI."""
