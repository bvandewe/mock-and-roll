"""Application layer for mock server CLI."""
